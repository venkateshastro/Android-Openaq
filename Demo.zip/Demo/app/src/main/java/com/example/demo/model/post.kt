package com.example.demo.model

data class Post(
    val location: String,
    val value: Float

)

