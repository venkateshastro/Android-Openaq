package com.example.demo

data class Todo (
    val location: String

)