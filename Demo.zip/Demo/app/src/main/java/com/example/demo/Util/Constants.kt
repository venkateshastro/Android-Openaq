package com.example.demo.Util

class Constants {
    companion object {
        const val BASE_URL = "https://api.openaq.org"
    }
}